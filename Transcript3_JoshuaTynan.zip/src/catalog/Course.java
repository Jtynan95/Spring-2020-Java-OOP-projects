package catalog;


public abstract class Course implements Print {
    private String institution;
    private String prefix;
    private String number;
    private  int credits;
    private  String name;
    private String semester;



    public Course(String Institution, String Prefix, String Number, int Credits, String Name, String Semester) {
        institution = Institution;
        prefix = Prefix;
        number = Number;
        credits = Credits;
        name = Name;
        semester = Semester;
    }
    String getInstitution(){ return institution;  }

    public void setInstitution(String institution) {
        this.institution = institution;
    }

    String getPrefix(){
        return prefix;
    }

    public void setPrefix(String prefix) {
        this.prefix = prefix;
    }

    String getNumber(){
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    public int getCredits(){
        return credits;
    }

    public void setCredits(int credits) {
        this.credits = credits;
    }

    String getName(){
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    String getSemester(){
        return semester;
    }

    public void setSemester(String semester) {
        this.semester = semester;
    }

   public void print(){
        System.out.println("Institution: " + getInstitution() + "\n"+ "Prefex: " + getPrefix()+ "\n" + "Number: "
       +getNumber() + "\n" + "Credits: " + getCredits() + "\n" + "Name: " +getName() + "\n" + "Semester: "
        +getSemester()+ "\n");
    }
}
