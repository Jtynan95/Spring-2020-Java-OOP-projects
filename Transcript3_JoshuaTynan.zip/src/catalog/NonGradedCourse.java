package catalog;

 public class NonGradedCourse extends Course{
   private String Days;
   private String StartTime;
   private String EndTime;
   private String BldgName;
   private String RoomNumber;
   private String InstructorName;


  public NonGradedCourse(String Institution, String Prefix, String Number, int Credits, String Name, String Semester,
                         String days, String startTime, String endTime, String bldgName
                         , String roomNumber, String instructorName){

   super(Institution, Prefix, Number,Credits,Name,Semester);

    Days = days;
    StartTime = startTime;
    EndTime  = endTime;
    BldgName = bldgName;
    RoomNumber = roomNumber;
    InstructorName = instructorName;
  }

   private String getDays (){return Days;}

     public void setDays(String days) {
         Days = days;
     }
     private String getStartTime(){return StartTime;}

     public void setStartTime(String startTime) {
         StartTime = startTime;
     }

     private String getEndTime(){return EndTime;}

     public void setEndTime(String endTime) {
         EndTime = endTime;
     }

     private String getBldgName(){return BldgName;}

     public void setBldgName(String bldgName) {
         BldgName = bldgName;
     }

     private String getRoomNumber(){return RoomNumber;}

     public void setRoomNumber(String roomNumber) {
         RoomNumber = roomNumber;
     }

     private String getInstructorName(){return InstructorName;}

     public void setInstructorName(String instructorName) {
         InstructorName = instructorName;
     }

     @Override
  public void print(){
     System.out.println("Institution: " + getInstitution() + "\n"+ "Prefex: " + getPrefix() + "\n" + "Number: "
            +getNumber() + "\n" + "Credits: " + getCredits() + "\n" + "Name: " +getName() + "\n" + "Semester: "
            +getSemester() + "\n" + "Days: " + getDays() + "\n" + "Start Time:  " + getStartTime()+ "\n" + "End Time: " + getEndTime()
            + "\n" + "Building Number: " + getBldgName() + "\n" + "Room Number: " + getRoomNumber() + "\n" + "Instructor Name: " + getInstructorName());
  }
}
