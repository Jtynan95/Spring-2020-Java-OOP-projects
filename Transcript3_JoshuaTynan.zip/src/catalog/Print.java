package catalog;

public interface Print {
     void print();
}
