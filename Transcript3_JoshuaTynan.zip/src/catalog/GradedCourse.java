package catalog;

 public class GradedCourse extends Course{
     String LetterGrade;
     double NumericalGrade;


    public GradedCourse(String Institution, String Prefix, String Number, int Credits, String Name, String Semester,
                        String letterGrade, double numericalGrade){

        super(Institution,Prefix,Number,Credits,Name,Semester);

        LetterGrade = letterGrade;
        NumericalGrade = numericalGrade;
    }
    

    String getLetterGrade(){return LetterGrade;}

     public void setLetterGrade(String letterGrade) {
         LetterGrade = letterGrade;
     }

     public double getNumericalGrade(){return NumericalGrade;}

     public void setNumericalGrade(double numericalGrade) {
         NumericalGrade = numericalGrade;
     }

     @Override
    public void print(){
        System.out.println("Institution: " + getInstitution() + "\n"+ "Prefex: " + getPrefix() + "\n" + "Number: "
                +getNumber() + "\n" + "Credits: " + getCredits() + "\n" + "Name: " +getName() + "\n" + "Semester: "
                +getSemester() + "\n" + "Letter Grade: " + getLetterGrade() + "\n" + "Numerical Grade: " + getNumericalGrade());

    }


 }
