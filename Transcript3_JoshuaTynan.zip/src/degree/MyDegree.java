package degree;
import catalog.Course;
import catalog.GradedCourse;
import catalog.NonGradedCourse;

import java.io.*;



public class MyDegree {
     public Course myCourseArray[] = new Course[5];
     int numberCourse = 0;

    public static void main(String[] args) {
    MyDegree start = new MyDegree();
    start.init();
    System.out.println("Transcript for Joshua Tynan: \n");
    start.print();
    }


    private void init(){
        try (BufferedReader br = new BufferedReader(new FileReader("transcript.txt"))){
            String line;
            int k = 0;

            while ((line = br.readLine()) != null){
                String[] info = line.split(",");
                for(int j = 0; j<info.length;j++) {
                    numberCourse++;
                    if (info.length == 8) {
                        int tempY = Integer.parseInt(info[3]);
                        double tempX = Double.valueOf(info[7]);
                        myCourseArray[k] =  new GradedCourse(info[0],info[1],info[2],tempY,info[4],info[5],info[6],tempX);
                        ((GradedCourse) myCourseArray[k]).getNumericalGrade();
                        k++;
                        info =  new String[0];
                    }

                    if (info.length == 12){
                        int tempY = Integer.parseInt(info[3]);
                        myCourseArray[k] = new NonGradedCourse(info[0],info[1],info[2],tempY,info[4],info[5],info[6],info[7],info[8],
                                info[9],info[10],info[11]);
                        k++;
                        info = new String[0];

                    }
                }
            }
        }
        catch (IOException e){
            e.printStackTrace();
        }
    }



   private void print(){
        int withoutGrade = 0;
        double credits = 0;
        double numGrade  = 0;
        double numericalGradeTotal = 0;
        for(Course co: myCourseArray){

            if(co.getClass().toString().contains("NonGradedCourse")){
                withoutGrade++;
            }
            else if (co.getClass().toString().contains("GradedCourse")){
                numericalGradeTotal = numericalGradeTotal + ((GradedCourse)co).getNumericalGrade();
            }
        }

       int courses = (myCourseArray.length - 1) - withoutGrade;
       for(int i = 0; i < myCourseArray.length; i++){
            myCourseArray[i].print();
            System.out.println("\n");
        }
        for(int i = 0; i < courses; i++){
            credits = myCourseArray[i].getCredits() + credits;
            numGrade = numericalGradeTotal * myCourseArray[i].getCredits();
        }

        double average = numGrade / credits;
        String Average = Double.toString(average);
        System.out.println("Total Courses for GPA: " + courses);
        System.out.println("Total Credits for GPA: " + credits);
        System.out.println("Total Courses Without Grade: " + withoutGrade);
        System.out.println("GPA: "  + Average.substring(0,4));
     }
}